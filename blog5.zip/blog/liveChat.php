<?php 
include "check_login.php";
  $notFound = 0;


 ?>
<html>
<head>
    <title>Home</title>
    <link rel="stylesheet"  href="assets/sidebar.css">
    <link rel="stylesheet"  href="assets/main_content.css">
    <link rel="stylesheet"  href="assets/chatstyle.css">
    <link rel="stylesheet" href="assets/fontawesome-free-6.4.0-web/css/all.min.css">
    <script src ="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    
</head>

<body>
<?php 
      include "includes/get_php/get_post.php";
      include "includes/get_php/get_comment.php";
      include_once "includes/get_php/get_user.php";
      include "assets/sidebar.php";

     
    if(isset($_GET['search'])){
        $key = $_GET['search'];
        $posts = search($db, $key);
        if ($posts == 0) {
            $notFound = 1;
        }
     }
        
?>


<div class="main_content">
    <div class="container">

         <div class ="message_box" >


            <div class="details-text">
                <h1 style="color: Green; text-align: center"
                id="chat_room" data-value="<?=$_SESSION['username']?>">LIVE CHAT</h1><br>

                    <div class="chat_box" style="height:400px;">
                        <div id="chat"></div>

                    </div><br>

                            <div class="message_input">
                                <input type="text" id="message" placeholder="Type your message...">
                                <button onclick="sendMessage()" id="mbtn"
                                data-value="<?=$user['user_id']?>"><i class ="fa-solid fa-paper-plane"></i>
                            </button>
                            </div>

                    </div>
            </div>
        
         



</div>
</div>


</body>
<script src="assets/sidebarscript.js"></script>
<script src="assets/chatlive.js"></script>
</html>