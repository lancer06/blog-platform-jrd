<?php
require_once 'vendor/autoload.php'; // Path to autoload.php from the SDK

$fb = new Facebook\Facebook([
    'app_id' => '258292387074722',
    'app_secret' => '02b4df5cb55b8a39e0f301798e9e3332',
    'default_graph_version' => 'v12.0', 
]);

$helper = $fb->getRedirectLoginHelper();
$permissions = ['email','username']; // Add additional permissions if needed

$loginUrl = $helper->getLoginUrl('http://localhost/blog/index.php', $permissions);

echo '<a href="' . htmlspecialchars($loginUrl) . '">Log in with Facebook!</a>';

$helper = $fb->getRedirectLoginHelper();

try {
    $accessToken = $helper->getAccessToken();
} catch (\Facebook\Exceptions\FacebookResponseException $e) {
    // When Graph returns an error
    echo 'Graph returned an error: ' . $e->getMessage();
    exit;
} catch (\Facebook\Exceptions\FacebookSDKException $e) {
    // When validation fails or other local issues
    echo 'Facebook SDK returned an error: ' . $e->getMessage();
    exit;
}

if (!isset($accessToken)) {
    echo 'Access denied: Unauthorized access or user denied permission.';
    exit;
}

?>