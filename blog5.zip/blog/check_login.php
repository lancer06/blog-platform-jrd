<?php
include_once "includes/db.php";
session_start();
$logged = false;


if(isset($_GET['session'])) {

    $sql = "SELECT * FROM user WHERE user_session=?";
    $stmt = $db->prepare($sql);
    $stmt->execute([$_GET['session']]);

    if($stmt->rowCount()==1){    
    $user = $stmt->fetch();

    $_SESSION['username']=$user['username'];
    $logged = true;
    }else{
        $logged=false;
        header("Location: login.php");
    }
}
?>