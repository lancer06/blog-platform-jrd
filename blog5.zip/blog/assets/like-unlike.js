$(document).ready(function(){
  $('#likeBtn').click(function(){
      var value = $(this).data('value');

      $.ajax({
          url: 'includes/like-unlike.php',
          type: 'POST',
          data: {value: value},
          success: function (data){
              $('#likeBtn').html(data);
          }
      })
  })
})