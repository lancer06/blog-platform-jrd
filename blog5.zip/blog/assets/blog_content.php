<?php 
include "get_post.php";
include

$posts = getAll($conn);
$categories = get5Categoies($conn); 

?>

<div class="main_content">
    
    
    <div class="container">
        <div class="card_container">
            <img class="pic" src="<?=$post['cover_url']?>" alt="">
            <div class="post_title"><?=$post['title']?></div>
            <div class="post_details">
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. 
                    Optio amet sunt fugiat cumque sapiente nobis iusto sit distinctio odio 
                    rerum dolores molestiae perferendis et hic ullam maiores repellat,
                     cupiditate soluta?</p><br>
                <a href="" class="read_more">READ MORE</a>
            </div>
            <div class="post_actions">
                
                <div class="action_tab">
                <i class ="fa-solid fa-thumbs-up" id="like_btn"></i> likes(
                    <span>0</span>
                )
                <i class ="fa-solid fa-message" id="cmnts_btn"></i> comments(
                    <span>0</span>
                )
                </div>               
            </div> 
        </div>

        

    </div>
    



</div>