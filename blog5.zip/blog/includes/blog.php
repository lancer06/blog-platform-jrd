<?php
    if($logged){
        $user=getuser($db,$_SESSION['username']);
    }
?>

<div class="main_content">

    <div class="container">
    <aside class="categorybox">
    <div class="category">
     <h2 align ="center">CATEGORY</h2>
        <?php if($logged){?>
            <?php foreach ($categories as $cat) { ?>
                <li><a href="category.php?session=<?=$_GET['session']?>&cat_id=<?=$cat['cat_id']?>"><?=$cat['category_name']?></a></li>
            <?php } ?>
        <?php }else{?>
            <?php foreach ($categories as $cat) { ?>
                <li><a href="category.php?cat_id=<?=$cat['cat_id']?>"><?=$cat['category_name']?></a></li>
            <?php } ?>
        <?php }?>
        </div>
    </aside>
    <?php if ($posts != 0) { ?>
    <?php foreach ($posts as $post) { 
    $author=getAuthorById($db,$post['author_id']);
    ?> 
        <div class="card_container">
            <img class="pic" src="<?=$post['cover_url']?>" alt="">
            <div class="post_title"><?=$post['title']?></div>
            <div class="post_details">
            <h4><?=$author['username']?></h4><br>
            <?php 
                $p = strip_tags($post['details']); 
                $p = substr($p, 0, 200);               
	        ?>
                <p><?=$p?>...</p><br>
                <?php if($logged){ ?>
                <a href="post_details.php?session=<?=$_GET['session']?>&post_ID=<?=$post['post_id']?>&userID=<?=$user['user_id']?>&commpage=1"
                class="read_more">READ MORE</a>
                <?php }else{ ?>
                    <a href="post_details.php?post_ID=<?=$post['post_id']?>"
                    class="read_more">READ MORE</a>
                <?php } ?>
                 
            </div>
            <div class="post_actions">
                
                <div class="action_tab">
                    <?php include "templates/likes.php" ;?>
                <i class ="fa-solid fa-message" id="cmnts_btn"></i> comments(
                    <span> <?php 
		                    echo CountByPostID($db, $post['post_id']);
				         ?></span>
                )
                <a href="https://www.facebook.com/sharer/sharer.php?u=http://localhost/blog/index.php" 
                target="_blank"><i class ="fa-brands fa-facebook" ></i>Share to Facebook</a>
                </div>               
            </div> 
        </div>      
            <?php } ?>
        <?php }else if($notFound==1) { ?>
            <h2>Not Found</h2>
        <?php } ?>
    </div>


</div>

