<?php  


session_id($_SESSION['user_session']);

session_start();

session_destroy();

header("Location: ../login.php");
exit;
?>