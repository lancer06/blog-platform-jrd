<?php 
session_start(); 

include "db.php";
if (isset($_POST['password']) && isset($_POST['username'])) {
    function validate($data){

       $data = trim($data);
       $data = stripslashes($data);
       $data = htmlspecialchars($data);
       return $data;
    }

    

    $password = validate($_POST['password']);
    $adminname = validate($_POST['username']);

    if(empty($adminname)){
        header("Location: ../admin.php?error=Username is required");
        exit();
    }else if(empty($password)) {
            header("Location: ../admin.php?error=Password is required");
            exit();
    }
    else{

        $sql = "SELECT * FROM admin WHERE username= :username";
        $result = $db->prepare($sql);
        $result->bindParam(':username', $adminname);
        $result->execute();
        $result->setFetchMode(PDO::FETCH_ASSOC);

        if ($result->rowCount() === 1) {
            $row = $result->fetch();

            $pass = $row['password'];
            

            if ($row['username']=== $adminname) {
                if(password_verify($password, $pass)){

                    echo "Logged in!";

                    $_SESSION['password'] = $row['password'];
                    $_SESSION['username'] = $row['username'];
                    

                    header("Location: ../admin-blogpage.php");
                    exit();
                    }else{
                        header("Location: ../admin.php?error=Incorrect password");
                    exit();
                }

            }else{
                header("Location: ../admin.php?error=Incorrect username");
                exit();
            }
        }else{
            header("Location: ../admin.php?error= Account does not exist");
            exit();
        }
    }

}else{
    header("Location: ../admin.php");
    exit();
}