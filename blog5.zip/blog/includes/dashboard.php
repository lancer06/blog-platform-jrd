
<div class="main_content">
    <div class="container">


    <div class ="profilebox" >
        <h2>Posts Info</h2><br>
        <?php 
        $auth= getauthor($db,$user['user_id']);
        $numPostsPub= getPostNumUserIDPublish($db, $auth['author_id']);
        $numPostsUnpub= getPostNumUserIDUnpublish($db, $auth['author_id']);
        $totalnumPosts =getPostNumUserID($db, $auth['author_id']);

        $commentsNum =getCommentCountUserID($db, $user['user_id']);
        $allcomments=getCommentByUserId($db,$user['user_id']);

        ?>
        <p>Published Post: <?=$numPostsPub?></p>
        <p>Unpublished Post: <?=$numPostsUnpub?></p>
        <br>
        <h3>Total: <?=$totalnumPosts?></h3>
            

    </div>

       

         <div class ="profilebox" >
            <h2>Comments</h2><br>
            <h3>Total: <?=$commentsNum?></h3>

            <div class="dash_comment_box">
                <div class="dash_comment_table">
                <table>
                        <tr>
                            <th>Post</th>
                            <th>comment</th>
                            <th>Date</th>
                            <th>Delete</th>
                        </tr>
                        <?php foreach($allcomments AS $comments){
                            $post=getById($db, $comments['post_id']);

                            $snippet = strip_tags($comments['comment']); 
                            $snippet = substr($snippet, 0, 15); 
                            ?>
                        <tr>
                            <td><a href="post_details.php?session=<?=$_GET['session']?>&post_ID=<?=$post['post_id']?>&userID=<?=$user['user_id']?>">
                            <?=$post['title']?></a></td>
                            <td><?=$snippet?>...</td>
                            <td><?=$comments['commentdate']?></td>
                            <td><button onclick ="ShowModal('myModal-<?=$comments['comment_id']?>')"
                            style="background: none; border: none;">
                            <i class ="fa-solid fa-trash"></i>
                            </button></td>

                                    <div id="myModal-<?=$comments['comment_id']?>" class="modal">
                                                <!-- Modal content -->
                                    <div class="modal-content">
                                    <span class="close" onclick ="CloseModal('myModal-<?=$comments['comment_id']?>')">&times;</span>
                                        <p>Delete Post?</p><br><br>
                                        <a href="user-dashboard.php?session=<?=$_GET['session']?>&delete=<?=$comments['comment_id']?>" 
                                        class="choice">Yes</a>
                                    <button onclick ="CloseModal('myModal-<?=$comments['comment_id']?>')"><h3>No</h3></button>
                                    </div>
                                </div>
                        </tr>
                        <?php }?>

                        <?php if(isset($_GET['delete'])){
                            $comID= $_GET['delete'];

                            $sql = "DELETE FROM comments WHERE comment_id=?";
                            $stmt = $db->prepare($sql);
                            $stmt->execute([$comID]);
                            ?>
                            <script>
                                window.location.replace("user-dashboard.php?session=<?=$_GET['session']?>");
                            </script>
                            <?php }?>
                </table>
                </div>
            </div>
            

           

        </div>

</div>
</div>
