<?php 
include "check_login.php";
  $notFound = 0;


 ?>
<html>
<head>
    <title>Home</title>
    <link rel="stylesheet"  href="assets/sidebar.css">
    <link rel="stylesheet"  href="assets/main_content.css">
    <link rel="stylesheet" href="assets/fontawesome-free-6.4.0-web/css/all.min.css">
    <script src ="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    
</head>

<body>
<?php 
      include_once "includes/db.php";
      include "includes/get_php/get_post.php";
      include "includes/get_php/get_comment.php";
      include_once "includes/get_php/get_user.php";
      include "assets/sidebar.php";

     
    if(isset($_GET['search'])){
        $key = $_GET['search'];
        $posts = search($db, $key);
        if ($posts == 0) {
            $notFound = 1;
        }
     }
        
     include "templates/profile.php";
?>


</body>
<script src="assets/sidebarscript.js"></script>

</html>