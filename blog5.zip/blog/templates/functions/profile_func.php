<?php
   require_once '../../includes/db.php';
   include_once '../../includes/get_php/get_user.php';

    $user_id = $_GET['userID'];
    $session=$_GET['session'];

    

    if ($_SERVER['REQUEST_METHOD'] === 'POST'){

        $username= $_POST['username'];
        $firstname= $_POST['firstname'];
        $lastname= $_POST['lastname'];
        $email= $_POST['email'];
        $user_id = $_GET['userID'];
        $imgname =$_FILES["image"]["name"];



        if(empty($imgname)){

            $sql = "UPDATE user SET firstname=?, lastname=?, email=?, username=? WHERE user_id=?";
            $stmt = $db->prepare($sql);
            $stmt->execute([$firstname,$lastname, $email, $username , $user_id]);


            header("Location: ../../profile_setting.php?session=$session");
        exit;

        }else{

            $targetDirectory = "../../assets/img/upload/";
            $imgURL = "assets/img/upload/" . $imgname;
            $targetFile = $targetDirectory . $imgname;
            $uploadOk = 1;
            $imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

        // Check if the file is an actual image or a fake image
        if (isset($_POST["submit"])) {
            $check = getimagesize($_FILES["image"]["tmp_name"]);
            if ($check === false) {
                $error = "File is not an image.";
                $uploadOk = 0;
                header("Location: ../../profile_setting.php?session=$session&edit&pic&error=$error");;
                exit();
            }
        }

        // Allow certain file formats
        $allowedExtensions = ["jpg", "jpeg", "png", "gif"];
        if (!in_array($imageFileType, $allowedExtensions)) {
            $error = "Sorry, only JPG, JPEG, PNG, and GIF files are allowed.";
            $uploadOk = 0;
            header("Location: ../../profile_setting.php?session=$session&edit&pic&error=$error");
            exit();
        }

        // Check if $uploadOk is set to 0 by an error
        if ($uploadOk == 0) {
            $error = "Sorry, your file was not uploaded.";
        }

    if (move_uploaded_file($_FILES["image"]["tmp_name"], $targetFile)) {

           
                $sql = "UPDATE user SET firstname=?, lastname=?, email=?, username=?, profilepic=? WHERE user_id=?";
                    $stmt = $db->prepare($sql);
                    $stmt->execute([$firstname,$lastname, $email, $username , $imgURL, $user_id]);


                    header("Location: ../../profile_setting.php?session=$session");
                exit;

            }
        }   
    }
?>