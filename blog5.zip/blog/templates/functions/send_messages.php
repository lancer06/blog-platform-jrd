<?php
include "../../includes/db.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST'){

    $message =$_POST['message'];
    $user_id = $_GET['userID'];

    $stmt = $db->prepare('INSERT INTO messages(message, user_id) VALUES (?,?)');
    $stmt->execute([$message, $user_id]);

}

?>