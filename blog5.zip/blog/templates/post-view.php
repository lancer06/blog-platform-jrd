<?php

$commentsPerPage = 4;
// Get the current page number from the query string
$page = isset($_GET['commpage']) ? (int)$_GET['commpage'] : 1;       
 // Calculate the starting index for comments on the current page
$startIndex = ($page - 1) * $commentsPerPage;

    $comments = getCommentsByPostID($db, $PID, $startIndex, $commentsPerPage);
?>
    <div class="main_content">
        <div class="container">

        <div class ="post_contain" >

            <div class="post_profile">
                <img class="pic"  src="<?=$post['cover_url']?>" alt="">
                </div><br>
                <div class="post_title"><?=$post['title']?></div>
                <div class="post_details">
                <h4><?=$author['username']?></h4><br
                    <p><?=$post['details']?></p><br>
                </div>
            </div>  

            <div class ="post_contain">
                <div>
                    <br>
                    <?php if($logged){ ?>               
                    <?php $userid=$_GET['userID']?>
                    <form class="post_comment" action="templates/functions/add_comment.php?postID=<?=$post['post_id']?>&userID=<?=$userid?>
                    &session=<?=$_GET['session']?>"
                    method="post">
                    <h4 style="color:green;">Write your comment:</h4>

                    <?php if (isset($_GET['error'])) { ?>
                            <p style="color:darkred;"><?php echo $_GET['error']; ?></p>
                        <?php } ?>

                    <textarea type="text" name="comment" class="commentbox"></textarea><br>

                    <button type="submit">Send</button>
                    </form>
                    <?php }else{?>
                        <div class="post_comment">
                        <h4 style="color:green;">Login First</h4>
                        </div>
                    <?php }?>
                </div> 
                

            </div>
            
    <?php include "templates/comments.php"; ?>

  </div>

