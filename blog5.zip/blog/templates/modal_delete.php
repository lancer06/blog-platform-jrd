<div id="myModal-<?=$post['post_id']?>" class="modal">
                        <!-- Modal content -->
    <div class="modal-content">
    <span class="close" onclick ="CloseModal('myModal-<?=$post['post_id']?>')">&times;</span>
        <p>Delete Post?</p><br><br>
        <a href="templates/functions/delete_func.php?session=<?=$_GET['session']?>&post_id=<?= $post['post_id']?>" 
            class="choice">Yes</a>
    <button onclick ="CloseModal('myModal-<?=$post['post_id']?>')"><h3>No</h3></button>
    </div>
</div>