<?php
	include "db_conn.php"; 
    function getallpost($db){
	    $sql="SELECT * FROM post";
	    $stmt = $db->prepare($sql);
   	     $stmt->execute();
	    $result =$stmt->fetchAll();
	return $result;	
};
    function getPostbyId($db,$id){
	    $sql="SELECT * FROM post INNER JOIN category ON post.cat_id = category.cat_id 
		INNER JOIN authors ON post.author_id = authors.author_id WHERE post_id=?";
	    $stmt = $db->prepare($sql);
   	    $stmt->execute([$id]);
	    $result =$stmt->fetch();
	    return $result;	
};
	function getallcategory($db){
		$sql="SELECT * FROM category";
		$stmt = $db->prepare($sql);
			$stmt->execute();
		$result =$stmt->fetchAll();
	return $result;	
};

      function addPost($db, $title, $details, $category, $author_id){
        $query = $db->prepare("INSERT INTO post (title, details, cat_id, author_id)  VALUES (?, ?, ?, ?)");
        $query->execute([$title, $details, $category, $author_id]);	
	};
?>
