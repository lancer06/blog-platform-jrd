<?php	
if(isset($_GET['list'])){
	  include "view/post_listing.php";
}
else if(isset($_GET['details'])){  
	    include "view/post_details.php"; 
}
elseif(isset($_GET['create'])){     
	    include "view/create_post.php";		    
}
?>
