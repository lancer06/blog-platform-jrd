<?php
include "../db_conn.php";
include "postFunctions.php";

   if ($_SERVER['REQUEST_METHOD'] === 'POST'){
        $title=$_POST['title'];
        $details=$_POST['details'];
        $category=$_POST['categoryid'];
        $authorId=$_POST['author_id'];

        if(empty($title)||empty($details)||empty($category)||empty($authorId)){
            header("Location: ../index.php?create&error=Fill all Inputs");
        exit;
        }else{
            addPost($db, $title, $details, $category, $authorId);
            header("Location: ../index.php");
            exit;
        }        
   }
?>