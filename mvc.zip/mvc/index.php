<?php 
    include "controller/postFunctions.php";
    include "view/header.php";
    include "controller/postController.php";
    include "view/footer.php"
?>