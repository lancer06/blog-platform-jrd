<?php
	$post=getPostbyId($db,$_GET['details']);
    
        echo "<h2>".$post['post_id']."</h2>";
        echo "<h3>".$post['title']."</h3>";
        echo "<h4>".$post['username']."</h4>";
        echo "<p>".$post['category_name']."</p>";
        echo "<p>".$post['details']."</p>";
?>