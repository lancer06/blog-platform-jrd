<form action="controller/createFunction.php" method="POST">
    <br>
    <label>Title</label>
    <input type="text" name="title"><br>
    <label>Details</label>
    <input type="text" name="details"><br>
    <label>Category Id</label><br>
    <?php 
    $categories=getallcategory($db);
    foreach($categories as $category){ ?>           
        <input type="radio" name="categoryid" id="cat-<?=$category['cat_id']?>" value ="<?=$category['cat_id']?>">
        <label for="cat-<?=$category['cat_id']?>"><?=$category['category_name']?></label> <br>          
     <?php }?>
    <label>Author Id</label>
    <input type="text" name="author_id"><br>
    <button type="submit">Save</button>
</form>