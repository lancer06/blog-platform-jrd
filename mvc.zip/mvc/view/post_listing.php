<?php
	$posts =getAllpost($db);
    
foreach($posts as $post){	
	echo "<h2>".$post['post_id']."</h2>";
    echo "<h3>".$post['title']."</h3>";
	echo "<p>".$post['details']."</p>";
?>
<a href="index.php?details=<?=$post['post_id']?>">Post Details</a>
<?php }?>
