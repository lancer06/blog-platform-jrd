<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Blog</title>
    <!-- Additional styles/scripts -->
</head>
<body>
<h4>Blog Display</h4>
<a href="index.php?list">Post list</a><br>
<a href="index.php?create">Create Post</a>
