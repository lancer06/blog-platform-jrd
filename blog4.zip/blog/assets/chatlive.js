
      var xhr = new XMLHttpRequest();
      var user = document.getElementById('chat_room').getAttribute('data-value');

      const chatList = document.getElementById('chat');

        function fetchMessage(){
            xhr.onreadystatechange = function () {
                if (xhr.readyState === XMLHttpRequest.DONE) {
                    if (xhr.status === 200) {
                        var messages = JSON.parse(xhr.responseText);

                        chatList.innerHTML = '';

                            messages.forEach(function(message){

                            var div = document.createElement('div');
                            var div2 = document.createElement('div');
                            var img = document.createElement('img');
                            var icon = document.createElement('img');
 
                            var h4 = document.createElement('h4');
                            var h5 = document.createElement('h5');
                            var li = document.createElement('li');
                            var del =document.createElement('button');
                            del.classList.add("chatdel-btn");
                            
                            div.classList.add("chatbubble");
                            div2.classList.add("mychat");
                            img.src = message.profilepic;
                            icon.src="assets/img/profile.png"
                            h4.textContent = message.username;
                            h5.textContent = message.date;
                            li.textContent = message.message;
                            del.textContent = "DEL";

                            if(message.username==user){

                                var messageID= message.message_id;
                                chatList.append(div2);


                                if(message.profilepic==''){
                                    div2.appendChild(icon);
                                }else{
                                    div2.appendChild(img);
                                }

                                div2.appendChild(h4);
                                div2.appendChild(li);
                               
                                del.onclick =function(){
                                    xhr.open('POST', 'templates/functions/del_chat.php', true);
                                    xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
                                    xhr.send("messageID="+messageID);
                                }

                                div2.appendChild(del);
                                div2.appendChild(h5);

                            }else{

                                if(message.profilepic==''){
                                    div.appendChild(icon);
                                }else{
                                    div.appendChild(img);
                                }
                                chatList.append(div);
                                div.appendChild(h4);
                                div.appendChild(li);
                                div.appendChild(h5);
                          
                            }
                        });
                    }
                }
            };
            xhr.open('GET', 'templates/functions/get_messages.php', true);
            xhr.send();
        }

        function sendMessage() {

            const messageInput = document.getElementById('message');
            var userid = document.getElementById('mbtn').getAttribute('data-value');
            const message = messageInput.value;
        
                xhr.open('POST', 'templates/functions/send_messages.php?userID='+userid, true);
                xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
                xhr.send('message=' + message);

                messageInput.value = '';
                fetchMessage();
        }

        fetchMessage();
        setInterval(fetchMessage, 1400);
        
