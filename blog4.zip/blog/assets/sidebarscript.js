let btn = document.querySelector("#btn");
let sidebar = document.querySelector(".sidebar");
let searchBtn = document.querySelector("#search");

btn.onclick = function(){
  sidebar.classList.toggle("active");
}
searchBtn.onclick = function(){
  sidebar.classList.toggle("active");
}


var navlinks = document.querySelectorAll(".side_links");
const windowPathname = window.location.pathname;

navlinks.forEach(navlinks=> {
  if(navlinks.href.includes(windowPathname)){
    navlinks.classList.add("activelinks"); 
  }
});
