<?php 
include "check_login.php";

  $notFound = 0;
 ?>
<html>
<head>
    <title>Home</title>
    <link rel="stylesheet"  href="assets/sidebar.css">
    <link rel="stylesheet"  href="assets/main_content.css">
    <link rel="stylesheet" href="assets/fontawesome-free-6.4.0-web/css/all.min.css">

    
</head>

<body>
<?php 
      
      include "includes/get_php/get_post.php";
      include "includes/get_php/get_comment.php";
      include_once "includes/get_php/get_user.php";
      include "assets/sidebar.php";

     
    if(isset($_GET['search'])){
        $key = $_GET['search'];
        $posts = search($db, $key);
        if ($posts == 0) {
            $notFound = 1;
        }
     }else {
        $posts = getAll($db);
     }
      $categories = get5Categoies($db);

      
       
     include "includes/blog.php";
?>


</body>
<script src="assets/sidebarscript.js"></script>
<script src="assets/checksession.js"></script>
<script>  

  
const conn = new WebSocket('ws://localhost:8080');
var sessionId;

    conn.onmessage= function(event){
        console.log(event.data);
        var sessionId = (event.data);
        
        // Use AJAX to send the sessionId to a PHP script on the same page
        const xhr = new XMLHttpRequest();
        xhr.open('POST', 'index.php', true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        
        // Send the sessionId as a parameter
        xhr.send('sessionId=' + encodeURIComponent(sessionId));
    };


    function loadData(Lid, Sid) {
        const clss = document.getElementById(Lid);
        var valueToSend = document.getElementById(Lid).getAttribute('data-value');
        var xhr = new XMLHttpRequest();

        if(clss.className=="fa-solid fa-thumbs-up liked"){
            clss.className= "fa-solid fa-thumbs-up unliked";
        }else{
            clss.className= "fa-solid fa-thumbs-up liked";
        }

        xhr.onreadystatechange = function () {
            if (xhr.readyState === 4) { 
                if (xhr.status === 200) {
                    document.getElementById(Sid).innerHTML = xhr.responseText;
                    
                } else {
                    document.getElementById(Sid).innerHTML = 'Error occurred.';
                }
            }
        };

        xhr.open('POST', 'includes/like-unlike.php?user_id=<?=$user['user_id']?>', true);
        xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
        xhr.send('value=' + encodeURIComponent(valueToSend));
    }
</script>


</html>