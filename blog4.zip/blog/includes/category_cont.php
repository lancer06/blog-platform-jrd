

<div class="main_content">

    <div class="container">
    <aside class="categorybox">
    <div class="category">
     <h2 align ="center">CATEGORY</h2>
        <?php if($logged){?>
            <?php foreach ($categories as $cat) { 
                if($cat['cat_id']==$cID){?>
                <li class="active_cat"><a href="category.php?session=<?=$_GET['session']?>&cat_id=<?=$cat['cat_id']?>"><?=$cat['category_name']?></a></li>
            <?php }else{ ?>
                <li><a href="category.php?session=<?=$_GET['session']?>&cat_id=<?=$cat['cat_id']?>"><?=$cat['category_name']?></a></li>
            <?php }}?>
        <?php }else{?>
            <?php foreach ($categories as $cat) { 
                if($cat['cat_id']==$cID){?>
                <li class="active_cat"><a href="category.php?cat_id=<?=$cat['cat_id']?>"><?=$cat['category_name']?></a></li>
            <?php }else{ ?>
                <li><a href="category.php?cat_id=<?=$cat['cat_id']?>"><?=$cat['category_name']?></a></li>
            <?php }}?>
        <?php }?>

        </div>
    </aside>
    <?php if ($posts != 0) { ?>
    <?php foreach ($posts as $post) { ?> 
        <div class="card_container">
            <img class="pic" src="<?=$post['cover_url']?>" alt="">
            <div class="post_title"><?=$post['title']?></div>
            <div class="post_details">
            <?php 
                $p = strip_tags($post['details']); 
                $p = substr($p, 0, 200);               
	        ?>
                <p><?=$p?>...</p><br>
                <?php if($logged){?>
                <a href="post_details.php?session=<?=$_GET['session']?>&post_ID=<?=$post['post_id']?>&userID=<?=$user['user_id']?>&commpage=1"
                class="read_more">READ MORE</a>
                <?php }else{?>
                <a href="post_details.php?post_ID=<?=$post['post_id']?>" class="read_more">READ MORE</a>
                <?php }?>
            </div>
            <div class="post_actions">
                
                <div class="action_tab">
                    <?php include "templates/likes.php" ;?>
                <i class ="fa-solid fa-message" id="cmnts_btn"></i> comments(
                    <span> <?php 
		                    echo CountByPostID($db, $post['post_id']);
				         ?></span>
                )
                </div>               
            </div> 
        </div>      
        <?php } ?>
        <?php }else if($notFound==1) { ?>
            <h2>Not Found</h2>
        <?php } ?>
    </div>
 
    
