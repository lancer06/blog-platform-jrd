<?php 

// Get All 
function getAll($db){
   $sql = "SELECT * FROM post 
           WHERE publish=1";
   $stmt = $db->prepare($sql);
   $stmt->execute();

   if($stmt->rowCount() >= 1){
   	   $data = $stmt->fetchAll();
   	   return $data;
   }else {
   	 return 0;
   }
}

function getAllPost($db){
   $sql = "SELECT * FROM post";
   $stmt = $db->prepare($sql);
   $stmt->execute();

   if($stmt->rowCount() >= 1){
   	   $data = $stmt->fetchAll();
   	   return $data;
   }else {
   	 return 0;
   }
}


function getPostNumUserID($db, $id){
   $sql = "SELECT * FROM post WHERE author_id=?";
   $stmt = $db->prepare($sql);
   $stmt->execute([$id]);

   if($stmt->rowCount() >= 1){
         $data = $stmt->rowCount();
         return $data;
   }else {
       return 0;
   }
}
function getPostNumUserIDPublish($db, $id){
   $sql = "SELECT * FROM post WHERE author_id=? & publish=1";
   $stmt = $db->prepare($sql);
   $stmt->execute([$id]);

   if($stmt->rowCount() >= 1){
         $data = $stmt->rowCount();
         return $data;
   }else {
       return 0;
   }
}
function getPostNumUserIDUnpublish($db, $id){
   $sql = "SELECT * FROM post WHERE author_id=? && publish=0";
   $stmt = $db->prepare($sql);
   $stmt->execute([$id]);

   if($stmt->rowCount() >= 1){
         $data = $stmt->rowCount();
         return $data;
   }else {
       return 0;
   }
}

// getPostsByCategory
function getPostsByCategory($conn, $category_id){
   $sql = "SELECT * FROM post  WHERE cat_id=? AND publish=1";
   $stmt = $conn->prepare($sql);
   $stmt->execute([$category_id]);

   if($stmt->rowCount() >= 1){
         $data = $stmt->fetchAll();
         return $data;
   }else {
       return 0;
   }
}

function getAllPostsByCategory($conn, $category_id){
   $sql = "SELECT * FROM post  WHERE cat_id=?";
   $stmt = $conn->prepare($sql);
   $stmt->execute([$category_id]);

   if($stmt->rowCount() >= 1){
         $data = $stmt->fetchAll();
         return $data;
   }else {
       return 0;
   }
}

// getById
function getById($conn, $id){
   $sql = "SELECT * FROM post 
           WHERE post_id=?";
   $stmt = $conn->prepare($sql);
   $stmt->execute([$id]);

   if($stmt->rowCount() >= 1){
         $data = $stmt->fetch();
         return $data;
   }else {
       return 0;
   }
}


// getById Deep - Admin
function getByIdDeep($conn, $id){
   $sql = "SELECT * FROM post WHERE post_id=?";
   $stmt = $conn->prepare($sql);
   $stmt->execute([$id]);

   if($stmt->rowCount() >= 1){
         $data = $stmt->fetch();
         return $data;
   }else {
       return 0;
   }
}

// search
function search($conn, $key){
   # creating simple search temple :)  
   $key = "%{$key}%";

   $sql = "SELECT * FROM post 
           WHERE publish=1 AND (title LIKE ? 
           OR details LIKE ?)";
   $stmt = $conn->prepare($sql);
   $stmt->bindParam($key,$key);
   $stmt->execute([$key, $key]);
   $stmt->setFetchMode(PDO::FETCH_ASSOC);


   if($stmt->rowCount() >= 1){
         $data = $stmt->fetchAll();
         return $data;
   }else {
       return 0;
   }
}

// getCategoryById
function getCategoryById($db, $id){
   $sql = "SELECT * FROM category WHERE cat_id=?";
   $stmt = $db->prepare($sql);
   $stmt->execute([$id]);

   if($stmt->rowCount() >= 1){
         $data = $stmt->fetch();
         return $data;
   }else {
       return 0;
   }
}

function getCategoryIDbyName($conn, $name){
   $sql = "SELECT cat_id FROM category WHERE category_name LIKE ?";
   $stmt = $conn->prepare($sql);
   $stmt->execute([$name]);

   if($stmt->rowCount() >= 1){
         $data = $stmt->fetch();
         return $data;
   }else {
       return 0;
   }
}

//get 5 Categoies 

function get5Categoies($conn){
   $sql = "SELECT * FROM category LIMIT 5";
   $stmt = $conn->prepare($sql);
   $stmt->execute();

   if($stmt->rowCount() >= 1){
         $data = $stmt->fetchAll();
         return $data;
   }else {
       return 0;
   }
}


// getAllCategories
function getAllCategories($conn){
   $sql = "SELECT * FROM category ORDER BY cat_id";
   $stmt = $conn->prepare($sql);
   $stmt->execute();

   if($stmt->rowCount() >= 1){
         $data = $stmt->fetchAll();
         return $data;
   }else {
       return 0;
   }
}

// Delete By ID
function deleteById($conn, $id){
   $sql = "DELETE FROM post WHERE post_id=?";
   $stmt = $conn->prepare($sql);
   $res = $stmt->execute([$id]);

   if($res){
   	   return 1;
   }else {
   	 return 0;
   }
}


function getByAuthorId($conn,$id){
   $sql = "SELECT * FROM post 
           WHERE author_id='$id'";
   $stmt = $conn->prepare($sql);
   $stmt->execute();

   if($stmt->rowCount() >= 1){
   	   $data = $stmt->fetchAll();
   	   return $data;
   }else {
   	 return 0;
   }
}

function getPostById($conn,$id){
   $sql = "SELECT * FROM post 
           WHERE post_id='$id'";
   $stmt = $conn->prepare($sql);
   $stmt->execute();

   if($stmt->rowCount() >= 1){
   	   $data = $stmt->fetch();
   	   return $data;
   }else {
   	 return 0;
   }
}

function getAuthorById($db,$id){
   $sql = "SELECT * FROM authors 
           WHERE author_id='$id'";
   $stmt = $db->prepare($sql);
   $stmt->execute();

   if($stmt->rowCount() >= 1){
   	   $data = $stmt->fetch();
   	   return $data;
   }else {
   	 return 0;
   }
}

