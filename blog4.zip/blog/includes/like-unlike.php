<?php  

session_start();

if (isset($_SESSION['username'])){
    
    include "db.php";
	include "get_php/get_comment.php";
	$user_id = $_GET['user_id'];
	$post_id = $_POST['value'];
	if (empty($post_id)) {
		echo "...";
	}else {
		$sql = "SELECT * FROM likes
		        WHERE post_id=? AND user_id=?";
    	$stmt = $db->prepare($sql);
    	$res = $stmt->execute([$post_id, $user_id]);

    	if($stmt->rowCount() > 0){
           // unlike
    		$sql  = "DELETE FROM likes
		            WHERE post_id=? AND user_id=?";
		    $stmt = $db->prepare($sql);
		    $res  = $stmt->execute([$post_id, $user_id]);

			echo likeCountByPostID($db, $post_id);
    	}else {
            $sql  = "INSERT INTO likes(post_id,user_id) VALUES(?,?)";
		    $stmt = $db->prepare($sql);
		    $res  = $stmt->execute([$post_id,$user_id]); 

			echo likeCountByPostID($db, $post_id);
    	}
        
    	
	}
	

	
    

}else {
	echo "...";
}