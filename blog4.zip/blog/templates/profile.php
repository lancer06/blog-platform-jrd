
<div class="main_content">
    <div class="container">
<?php if(isset($_GET['edit'])){?>

        <form class ="profilebox" action="templates/functions/profile_func.php?userID=<?=$user['user_id']?>
        &session=<?=$_GET['session']?>" 
        method="post" enctype="multipart/form-data">
            

            <h1 style="color: Green; text-align: center">PROFILE INFO</h1><br>
            <?php if(empty($user['profilepic'])){?>
                <img src="assets/img/profile.png" alt=""><br><br>
            <?php }else{?>
                <img src="<?=$user['profilepic']?>" alt=""><br><br>
            <?php }?>

           <?php if(!isset($_GET['pic'])){?>
                <a href="profile_setting.php?edit&pic&session=<?=$_GET['session']?>"><p>
                    Edit Profile Picture</p></a>
            <?php }?>
            <div class="profile_inner">

            <h2>Username: </h2>
            <input class="inp" name="username" type="text" value="<?=$user['username']?>"><br>

            <?php if(isset($_GET['pic'])){?>
                <br>
                <p>Edit Profile Picture: </p>
                <input class="prof-pic" type="file" name="image" style="width: 400px;" id="image" accept="image/*">
                <br>
            <?php }?>
            <p>Firstname: </p>
            <input class="inp" name="firstname" type="text" value="<?=$user['firstname']?>">
            <p>Lastname: </p>
            <input class="inp" name="lastname" type="text" value="<?=$user['lastname']?>">
            <p>Email: </p>
            <input class="inp" name="email" type="text" value="<?=$user['email']?>">
            <br><br><br>

            <button type="submit" name="submit">Save Profile</button>
            <br>

            </form>

        </div>

<?php }else{?>
         <div class ="profilebox" >
            

            <h1 style="color: Green; text-align: center">PROFILE INFO</h1><br>
            <?php if(empty($user['profilepic'])){?>
                <img src="assets/img/profile.png" alt=""style="width: 200px; margin-left: 25%;"><br><br>
            <?php }else{?>
                <img src="<?=$user['profilepic']?>" alt=""style="width: 200px; margin-left: 25%;"><br>
            <?php }?>
            <div class="profile_inner">

            <h2>Username: <?=$user['username']?></h2><br>
            <p>Firstname: <?=$user['firstname']?></p>
            <p>Lastname: <?=$user['lastname']?></p>
            <p>Email: <?=$user['email']?></p><br><br><br>

            <a href="profile_setting.php?edit&session=<?=$_GET['session']?>"><h4 style="color: green;">Edit Profile</h4></a>
            <br>
            <a href="user-dashboard.php?session=<?=$_GET['session']?>"><h4 style="color: green;"><i class ="fa-solid fa-chart-area"></i>
            User Dashboard</h4></a>
            <br>

            </div>

        </div>

<?php }?>
</div>
</div>
