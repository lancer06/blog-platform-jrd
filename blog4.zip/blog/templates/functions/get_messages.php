<?php
include "../../includes/db.php";

$stmt = $db->prepare('SELECT * FROM messages INNER JOIN user ON user.user_id = messages.user_id
LIMIT 11');
$stmt->execute();
$messages = $stmt->fetchAll();

echo json_encode($messages);

