<?php
    include "../../includes/db.php";


    $post_id = $_GET['postID'];
    $user_id = $_GET['userID'];
    $comment_id= $_GET['commentID'];
    
    $session=$_GET['session'];
    

            $sql = "DELETE FROM comments WHERE comment_id=?";
            $stmt = $db->prepare($sql);
            $stmt->execute([$comment_id]);

            header("Location: ../../post_details.php?session=$session&post_ID=$post_id&userID=$user_id");
            exit;
      
    

?>