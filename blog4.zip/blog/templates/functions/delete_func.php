<?php
    include "../../includes/db.php";
    include "../../includes/get_php/get_post.php";

    $post_id = $_GET['post_id'];
    $session=$_GET['session'];
    $author= getById($db,$post_id);
    $authorid = $author['author_id'];
    

    $sql = "DELETE FROM post WHERE post_id=?";
    $stmt = $db->prepare($sql);
    $stmt->execute([$post_id]);

    header("Location: ../../my_blogs.php?session=$session&authorID=$authorid");
    exit;

?>