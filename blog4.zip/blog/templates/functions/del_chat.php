<?php
include "../../includes/db.php";

    $message_id = $_POST['messageID'];

    $sql = "DELETE FROM messages WHERE message_id=?";
    $stmt = $db->prepare($sql);
    $stmt->execute([$message_id]);


?>