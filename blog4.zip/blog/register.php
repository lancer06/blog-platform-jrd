<html>
<head>
    <title>User Sign Up</title>
    <link rel="stylesheet"  href="assets/style.css">

</head>

<body>

  <form action="includes/register_user.php" method="post">

    <h1 style="color: Green; text-align: center">SIGN UP</h1>

        <?php if (isset($_GET['error'])) { ?>
            <p class="error"><?php echo $_GET['error']; ?></p>
        <?php } else if (isset($_GET['success'])) { ?>
            <p class="success"><?php echo $_GET['success']; ?></p>
        <?php } ?>


    <label>First name</label>
    <input type="text" name="firstname" ><br>

    <label>Last name</label>
    <input type="text" name="lastname" ><br>
    
    <label>Email</label>
    <input type="text" name="email"placeholder="example@email.com" ><br>

    <label>Username</label>
    <input type="text" name="username" ><br>

    <label>Password</label>
    <input type="password" name="password" placeholder="Password"><br> 


    <button type="submit" style="font-size: 16px;">DONE</button><br><break>
    <a class= "links" href="index.php"><< Back to Login</a><br>

  </form>



</body>



</html>