

<div class="main_content">

    <div class="container">
    <aside class="categorybox">
    <div class="category">
     <h2 align ="center">CATEGORY</h2>
        <?php foreach ($categories as $cat) { 
            if($cat['cat_id']==$cID){?>
            <li class="active_cat"><a href="category.php?cat_id=<?=$cat['cat_id']?>"><?=$cat['category_name']?></a></li>
        <?php }else{ ?>
            <li><a href="category.php?cat_id=<?=$cat['cat_id']?>"><?=$cat['category_name']?></a></li>
        <?php }}?>
        </div>
    </aside>
    <?php if ($posts != 0) { ?>
    <?php foreach ($posts as $post) { ?> 
        <div class="card_container">
            <img class="pic" src="<?=$post['cover_url']?>" alt="">
            <div class="post_title"><?=$post['title']?></div>
            <div class="post_details">
            <?php 
                $p = strip_tags($post['details']); 
                $p = substr($p, 0, 200);               
	        ?>
                <p><?=$p?>...</p><br>
                <a href="post_details.php?post_ID=<?=$post['post_id']?>" class="read_more">READ MORE</a>
            </div>
            <div class="post_actions">
                
                <div class="action_tab">
                <i class ="fa-solid fa-thumbs-up" id="like_btn"></i> likes(
                    <span>0</span>
                )
                <i class ="fa-solid fa-message" id="cmnts_btn"></i> comments(
                    <span>0</span>
                )
                </div>               
            </div> 
        </div>      
        <?php } ?>
        <?php }else if($notFound==1) { ?>
            <h2>Not Found</h2>
        <?php } ?>
    </div>
 
    
