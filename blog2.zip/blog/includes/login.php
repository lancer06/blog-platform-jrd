<?php 
session_start(); 

include "db.php";
if (isset($_POST['password']) && isset($_POST['username'])) {
    function validate($data){

       $data = trim($data);
       $data = stripslashes($data);
       $data = htmlspecialchars($data);
       return $data;
    }

    

    $password = validate($_POST['password']);
    $username = validate($_POST['username']);

    if(empty($username)){
        header("Location: ../login.php?error=Username is required");
        exit();
    }else if(empty($password)) {
            header("Location: ../login.php?error=Password is required");
            exit();
    }
    else{

        $sql = "SELECT * FROM user WHERE username= :username";
        $result = $db->prepare($sql);
        $result->bindParam(':username', $username);
        $result->execute();
        $result->setFetchMode(PDO::FETCH_ASSOC);

        if ($result->rowCount() === 1) {
            $row = $result->fetch();

            $pass = $row['password'];
            

            if ($row['username']=== $username) {
                if(password_verify($password, $pass)){

                    echo "Logged in!";

                    $_SESSION['password'] = $row['password'];
                    $_SESSION['username'] = $row['username'];
                    

                    header("Location: ../index.php");
                    exit();
                    }else{
                        header("Location: ../login.php?error=Incorrect password");
                    exit();
                }

            }else{
                header("Location: ../login.php?error=Incorrect username");
                exit();
            }
        }else{
            header("Location: ../login.php?error= Account does not exist");
            exit();
        }
    }

}else{
    header("Location: ../login.php");
    exit();
}