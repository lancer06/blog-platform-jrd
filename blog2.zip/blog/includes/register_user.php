<?php 
require 'config.php';
include "db.php";

if(isset($_POST['firstname']) && isset($_POST['lastname']) &&
   isset($_POST['email']) && isset($_POST['username']) && 
   isset($_POST['password'])){

    function validate($data){

        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
 
     }


    $firstname = $_POST['firstname'];
    $lastname = $_POST['lastname'];
    $email = $_POST['email'];
    $username = $_POST['username'];
    $password = $_POST['password'];

    

    if(empty($firstname)){
        header("Location: ../register.php?error=First name is required");
        exit();

    }else if(empty($lastname)){
        header("Location: ../register.php?error=Last name is required");
        exit();

    }else if(empty($username)){
        header("Location: ../register.php?error=Username is required");
        exit();

    }else if(empty($email)){
        header("Location: ../register.php?error=Email is required");
        exit();

    }else if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
        header("Location: ../register.php?error=Invalid Email");
        exit();

    }else if(empty($password)) {
            header("Location: ../register.php?error=Password is required");
            exit();

    }else if(strlen($password)<10){
            header("Location: ../register.php?error=Password length should be at 10");
            exit();
    
    }else{

    	// hashing the password
    	$password = password_hash($password, PASSWORD_BCRYPT);

    	$sql = "INSERT INTO user(firstname, lastname, email, username, password) 
    	        VALUES(?,?,?,?,?)";
    	$stmt = $db->prepare($sql);
    	$stmt->execute([$firstname, $lastname, $email,$username, $password]);

    	header("Location: ../register.php?success=Account has been successfully created");
	    exit;
    }


}else {
	header("Location: ../register.php?error=error");
	exit;
}
