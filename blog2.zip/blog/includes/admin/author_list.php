<?php
    $users = getAllAuthors($db);
?>

<div class="main_content">
    

    <div class="container">
    
   
    <div class="card_container">
        
    <div class="card-table">
        <table style="width:800px;">
            <tr>
                <th>Author ID</th>
                <th>Firstname</th>
                <th>Lastname</th>
                <th>Email</th>
                <th>Username</th>
                <th>Action</th>
                
         </tr>
        <?php if ($users != 0) { ?>
        <?php foreach ($users as $user) { 
            
            ?> 
            <tr>
                <td><?=$user['author_id']?></td>
                <td><?=$user['firstname']?></td>
                <td><?=$user['lastname']?></td>
                <td><?=$user['email']?></td>
                <td><?=$user['username']?></td>    
                <td><a href="">REMOVE AUTHOR</a></td>         
            </tr>
        <?php } ?>    
        </table>
    </div>
           
        </div>

        <?php }else { ?>
    </div>


  <?php if($notFound){ ?>
  Not found
  <?php } ?>

<?php } ?>

    


</div>

