<html>
<head>
    <title>User Login</title>
    <link rel="stylesheet"  href="assets/style.css">

</head>

<body>

  <form action="includes/login.php" method="post">

    <h1 style="color: Green; text-align: center">LOGIN</h1>

        <?php if (isset($_GET['error'])) { ?>
            <p class="error"><?php echo $_GET['error']; ?></p>
        <?php } ?>

    <label>Username</label>

    <input type="text" name="username" ><br>

    <label>Password</label>

    <input type="password" name="password" placeholder="Password"><br> 

    <button type="submit" style="font-size: 16px;">Login</button><br><break>
    <a class= "links" href="includes/guest.php">Enter as Guest</a><br><br>
    <a class= "links" href="Register.php">Create New Account?</a>

  </form>



</body>



</html>