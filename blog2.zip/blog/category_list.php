<?php 
session_start();
$logged = false;
if (isset($_SESSION['username'])) {
	 $logged = true;
    }
  $notFound = 0;
 ?>
<html>
<head>
    <title>User Login</title>
    <link rel="stylesheet"  href="assets/sidebar.css">
    <link rel="stylesheet"  href="assets/main_content.css">
    <link rel="stylesheet" href="assets/fontawesome-free-6.4.0-web/css/all.min.css">

</head>

<body>
    <?php
    
      include_once "includes/db.php";
      include "includes/get_php/get_post.php";
      include_once 'includes/get_php/get_user.php';
      include "assets/sidebar.php";

      $categories = getAllCategories($db); 
    ?>
    <div class="main_content">
        <div class ="categorylist" >
            <div class="category">

            <h1 style="color: Green; text-align: center">CATEGORIES</h1>
            <?php foreach ($categories as $cat) { ?>
            <li><a href="category.php?cat_id=<?=$cat['cat_id']?>"><?=$cat['category_name']?></a></li>
            <?php } ?>

            </div>

        </div>
  </div>


</body>
<script src="assets/sidebarscript.js"></script>


</html>