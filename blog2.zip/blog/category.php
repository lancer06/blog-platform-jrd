<?php 
session_start();
$logged = false;


if (isset($_SESSION['username'])) {
	 $logged = true;
    }
  $notFound = 0;


 ?>
<html>
<head>
    <title>Home</title>
    <link rel="stylesheet"  href="assets/sidebar.css">
    <link rel="stylesheet"  href="assets/main_content.css">
    <link rel="stylesheet" href="assets/fontawesome-free-6.4.0-web/css/all.min.css">
    
</head>

<body>
<?php 
      include_once "includes/db.php";
      include "includes/get_php/get_post.php";
      include "includes/get_php/get_comment.php";
      include_once 'includes/get_php/get_user.php';
      include "assets/sidebar.php";


    $cID=$_GET['cat_id'];


      if(isset($_GET['search'])){
        $key = $_GET['search'];
        $posts = search($db, $key);

        if ($posts == 0) {
            $notFound = 1;
        }
     }else {
        $posts =  getPostsByCategory($db, $cID);
        if ($posts == 0) {
          $notFound = 1;
      }
     }
      $categories = get5Categoies($db);
       
     include "includes/category_cont.php";
?>


</body>
<script src="assets/sidebarscript.js"></script>


</html>