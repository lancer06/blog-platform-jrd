<?php 
session_start();
$logged = false;


if (isset($_SESSION['username'])) {
	 $logged = true;
    }
  $notFound = 0;


 ?>
<html>
<head>
    <title>Home</title>
    <link rel="stylesheet"  href="assets/sidebar.css">
    <link rel="stylesheet"  href="assets/main_content.css">
    <link rel="stylesheet"  href="assets/post-view_style.css">
    <link rel="stylesheet" href="assets/fontawesome-free-6.4.0-web/css/all.min.css">
    
</head>

<body>
<?php 
      include_once "includes/db.php";
      include "includes/get_php/get_post.php";
      include "includes/get_php/get_comment.php";
      include_once 'includes/get_php/get_user.php';
      include "assets/sidebar.php";

      $PID =$_GET['post_ID'];

      if(isset($_GET['search'])){
        $key = $_GET['search'];
        $posts = search($db, $key);

        if ($posts == 0) {
            $notFound = 1;
        }
     }else {
        $post = getById($db, $PID);
        $author=getAuthorById($db,$post['author_id']);
     }
      $categories = get5Categoies($db);
      
       
     include "templates/post-view.php";
?>


</body>
<script src="assets/sidebarscript.js"></script>


</html>