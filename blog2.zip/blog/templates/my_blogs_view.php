
<div class="main_content">

    <div class="container">

    <div class="add_post">
    <?php $user= getuser($db,$_SESSION['username']) ?> 
     <a href="templates/create_post.php?user_id=<?=$user['user_id']?>"><h2>+Post Blog</h2></a>
    </div>

    <?php if ($posts != 0) { ?>


    <?php foreach ($posts as $post) { ?> 
        <?php if($post['publish'] !=0){  ?>
        <div class="card_container">
            <img class="pic" src="<?=$post['cover_url']?>" alt="">
            <div class="post_title"><?=$post['title']?></div>
            <div class="post_details">
            <?php 
                $p = strip_tags($post['details']); 
                $p = substr($p, 0, 200);               
	        ?>
                <p><?=$p?>...</p><br>
                <a href="post_details.php?post_ID=<?=$post['post_id']?>&userID=<?=$user['user_id']?>&commpage=1"
                 class="read_more">READ MORE</a>
                <a href="templates/edit_post.php?post_id=<?= $post['post_id']?>" class="read_more">EDIT</a>
                <button class="remove" onclick ="ShowModal('myModal-<?=$post['post_id']?>')">DELETE</button>

                    <!-- The Modal -->
                    <?php include "modal_delete.php";?>

            </div>
            <div class="post_actions">
                
                <div class="action_tab">
                <i class ="fa-solid fa-thumbs-up" id="like_btn"></i> likes(
                    <span><?php echo  likeCountByPostID($db, $post['post_id']); ?></span>
                )
                <i class ="fa-solid fa-message" id="cmnts_btn"></i> comments(
                    <span> <?php 
		                    echo CountByPostID($db, $post['post_id']);
				         ?></span>
                )
                </div>               
            </div> 
        </div>
        <?php }else{ ?>
        <div class="card_container">
            <h3>Unpublished</h3><br>
            <img class="pic" src="<?=$post['cover_url']?>" alt="">
            <div class="post_title"><?=$post['title']?></div>
            <div class="post_details">
            <?php 
                $p = strip_tags($post['details']); 
                $p = substr($p, 0, 200);               
	        ?>
                <p><?=$p?>...</p><br>
                <a href="post_details.php?post_ID=<?=$post['post_id']?>&userID=<?=$user['user_id']?>&commpage=1" class="read_more">READ MORE</a>
                <a href="templates/edit_post.php?post_id=<?= $post['post_id']?>" class="read_more">EDIT</a>
                <button class="publish" onclick ="ShowModal('pubModal-<?=$post['post_id']?>')">PUBLISH</button>
                <!-- Modal -->
                    <?php include "modal_publish.php";?>
                <button class="remove" onclick ="ShowModal('myModal-<?=$post['post_id']?>')">DELETE</button>

                <!-- Modal -->
                <?php include "modal_delete.php";?>

            </div>
            <div class="post_actions">
                
                <div class="action_tab">
                <i class ="fa-solid fa-thumbs-up" id="like_btn"></i> likes(
                    <span><?php echo  likeCountByPostID($db, $post['post_id']); ?></span>
                )
                <i class ="fa-solid fa-message" id="cmnts_btn"></i> comments(
                    <span> <?php 
		                    echo CountByPostID($db, $post['post_id']);
				         ?></span>
                )
                </div>               
            </div> 
            </div>    
        <?php } ?>
            <?php } ?>
        <?php }else if($notFound==1) { ?>
            <h2>Not Found</h2>
        <?php } ?>
    </div>


</div>