<?php 
session_start();
$logged = false;


if (isset($_SESSION['username'])) {
	 $logged = true;
    }
  $notFound = 0;


 ?>
<html>
<head>
    <title>Home</title>
    <link rel="stylesheet"  href="../assets/sidebar.css">
    <link rel="stylesheet"  href="../assets/main_content.css">
    <link rel="stylesheet" href="../assets/fontawesome-free-6.4.0-web/css/all.min.css">
    
</head>
<body>

<?php
      include_once "../includes/db.php";
      include "../includes/get_php/get_post.php";
      include "../includes/get_php/get_comment.php";
      include_once "../includes/get_php/get_user.php";


        
     $author= getauthor($db,$_GET['user_id']);
 
     $categories = getAllCategories($db);
?>
    <div class="main_content-create">
        <div class="container">

        <form class="create_post" action="create_func.php" 
        method="post" enctype="multipart/form-data">

        <h1 style="color: Green; text-align: center">Create Post</h1>

        <?php if (isset($_GET['error'])) { ?>
            <p class="error"><?php echo $_GET['error']; ?></p>
        <?php } ?>

        <label>Title</label>
        <input type="text" name="title" ><br>

        <label>Description</label>
        <textarea name="content" required></textarea><br>

        <label>Category</label>
        <div class="cat_box">
        <?php foreach($categories as $category){ ?>
            <div class="catbtns">
                <div style="width:50px;">
                    <input type="radio" name="category" id="cat_b" value ="<?=$category['cat_id']?>">
                </div>
            <label for="cat_b"><?=$category['category_name']?></label> 
            </div>          
        <?php }?>
        </div>
        <label for="image">Upload Image:</label>
        <input type="file" name="image" id="image" accept="image/*"><br><br>

        
        <button type="submit" style="font-size: 16px;">SAVE</button><br><br>
        <a class= "links" href="../my_blogs.php?authorID=<?=$author['author_id']?>"><< Back</a><br><br>

        </form>

        </div>
    </div>


</body>

</html>