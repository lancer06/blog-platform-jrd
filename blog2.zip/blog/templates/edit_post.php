<?php 
session_start();
$logged = false;


if (isset($_SESSION['username'])) {
	 $logged = true;
    }
  $notFound = 0;


 ?>
<html>
<head>
    <title>Home</title>
    <link rel="stylesheet"  href="../assets/sidebar.css">
    <link rel="stylesheet"  href="../assets/main_content.css">
    <link rel="stylesheet" href="../assets/fontawesome-free-6.4.0-web/css/all.min.css">
</head>
<body>

<?php
      include_once "../includes/db.php";
      include "../includes/get_php/get_post.php";
      include "../includes/get_php/get_comment.php";
      include_once "../includes/get_php/get_user.php";
      include "../assets/sidebar.php";

    $id =$_GET['post_id'];        

      if(isset($_GET['search'])){
        $key = $_GET['search'];
        $posts = search($db, $key);
        if ($posts == 0) {
            $notFound = 1;
        }
     }
     $post = getPostById($db,$id);     

     $categories = getAllCategories($db);
?>
    <div class="main_content">
        <div class="container">

        <form class="create_post" action="functions/edit_func.php?post_id=<?=$id?>" 
        method="post" enctype="multipart/form-data">

        <h1 style="color: Green; text-align: center">Edit Post</h1>

        <?php if (isset($_GET['error'])) { ?>
            <p class="error"><?php echo $_GET['error']; ?></p>
        <?php } ?>

        <label>Title</label>
        <input type="text" name="title" value="<?=$post['title']?>"><br>

        <label>Description</label>
        <textarea name="content" id="details" required ></textarea><br>

        <label>Category</label>
        <div class="cat_box">
        <?php foreach($categories as $category){ ?>
            <?php if($category['cat_id']==$post['cat_id']){?>
                <div class="catbtns">
                    <div style="width:50px;">
                        <input type="radio" name="category" id="cat_b" value ="<?=$category['cat_id']?>"
                        checked ="checked">
                    </div>
                <label for="cat_b"><?=$category['category_name']?></label> 
                </div> 
            <?php }else{?>
                <div class="catbtns">
                    <div style="width:50px;">
                        <input type="radio" name="category" id="cat_b" value ="<?=$category['cat_id']?>">
                    </div>
                <label for="cat_b"><?=$category['category_name']?></label> 
                </div>
            <?php }?>         
        <?php }?>
        </div>
        <label for="image">Upload Image:</label>
        <input type="file" name="image" id="image" value="<?=$post['cover_url']?>" accept="image/*"><br><br>

        
        <button type="submit" style="font-size: 16px;">SAVE</button><br><break>
       
        </form>

        </div>
    </div>


</body>
<script src="../assets/sidebarscript.js"></script>
<script>
    document.getElementById("details").value ="<?=$post['details']?>";
</script>
</html>