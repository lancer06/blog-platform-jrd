<?php
    include "../../includes/db.php";
    include "../../includes/get_php/get_comment.php";

    $post_id = $_GET['postID'];
    $user_id = $_GET['userID'];
    
    $comment =getUserCommentByPost($db, $user_id , $post_id);
    
            $sql = "DELETE FROM comments WHERE comment_id=?";
            $stmt = $db->prepare($sql);
            $stmt->execute([$comment['comment_id']]);

            header("Location: ../../post_details.php?post_ID=$post_id&userID=$user_id");
            exit;
      
    

?>