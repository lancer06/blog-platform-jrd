<?php
       include "../../includes/db.php";
       include "../../includes/get_php/get_comment.php";

    $post_id = $_GET['postID'];
    $user_id = $_GET['userID'];

    if(isset($_POST['comment_edit'])) { 
        $comment=$_POST['comment_edit'];
        $commID =$_GET['commID'];
        $sql= $db->prepare("UPDATE comments SET comment=?
        WHERE comment_id=?");
        $sql->execute([$comment,$commID]);
        header("Location: ../../post_details.php?post_ID=$post_id&userID=$user_id");
        exit;
    }
    

   

?>