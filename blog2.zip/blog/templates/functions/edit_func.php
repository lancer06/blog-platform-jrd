<?php
// Include the necessary files (db.php, authentication, etc.)
require_once '../../includes/db.php';
include_once '../../includes/get_php/get_user.php';

// Start the session if not already started
session_start();

// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    // Redirect to the login page if the user is not logged in
    header('Location: index.php');
    exit();
}

// Handle the form submission
if(isset($_POST['title']) && isset($_POST['content']) &&
   isset($_POST['category']) && isset($_FILES['image']['name'])){

    // Retrieve data from the form
    $postID = $_GET['post_id'];
    $title = $_POST['title'];
    $content = $_POST['content'];
    $author = $_SESSION['author_id'];
    $cat_id = $_POST['category'];
    $imgname =  $_FILES['image']['name']; // Assuming you store the username in the session

    // Validate form data (add more validation as needed)
    if (empty($title) || empty($content)) {
        $error = "Title and content are required";
    } else {

        // Handle file upload    
        $targetDirectory = "../../assets/img/upload/";
        $fileURL = "assets/img/upload/" . $imgname;
        $targetFile = $targetDirectory . $imgname;
        $uploadOk = 1;
        $imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

        // Check if the file is an actual image or a fake image
        if (isset($_POST["submit"])) {
            $check = getimagesize($_FILES["image"]["tmp_name"]);
            if ($check === false) {
                header("Location: ../edit_post.php?error=File is not an image.");
                $uploadOk = 0;
                exit;
            }
        }

        // Check if the file already exists
        /*if (file_exists($targetFile)) {
            
            header("Location: create_post.php?error=Sorry, this file already exists.");
            $uploadOk = 0;
            exit;
        }

        */
        
        // Check file size
        /*if ($_FILES["image"]["size"] > 500000) {
            $error = "Sorry, your file is too large.";
            header("Location: create_post.php?error=Sorry, your file is too large.");
            $uploadOk = 0;
            exit;
        }*/

        // Allow certain file formats
        $allowedExtensions = ["jpg", "jpeg", "png", "gif"];
        if (!in_array($imageFileType, $allowedExtensions)) {  
            header("Location: ../edit_post.php?error=Sorry, only JPG, JPEG, PNG, and GIF files are allowed.");
            $uploadOk = 0;
            exit;
        }

        // Check if $uploadOk is set to 0 by an error
        if ($uploadOk == 0) {
            $error = "Sorry, your file was not uploaded.";
        } else {
            // If everything is ok, try to upload the file
            if (move_uploaded_file($_FILES["image"]["tmp_name"], $targetFile)) {
                // Insert the new post into the database with the image filename

                

                $query = $db->prepare("UPDATE post SET title=?, details=?, cat_id=?, author_id=? ,cover_url=?
                WHERE post_id=$postID");
                $query->execute([$title, $content, $cat_id, $author, $fileURL]);
                
                // Redirect to the dashboard or post list page after successful submission
                $au= getauthor($db,$author);
                $au=$au['author_id'];
                header("Location: ../../my_blogs.php?authorID=$au");
                exit();
            } else {
                header("Location: ../edit_post.php?error=error");
	            
            }
        }
    }
}