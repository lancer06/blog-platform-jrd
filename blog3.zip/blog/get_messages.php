<?php
// Assuming your PDO connection is set up in the server.php file
include "includes/db.php";

$stmt = $db->prepare('SELECT message FROM messages');
$stmt->execute();
$messages = $stmt->fetchAll();

echo json_encode($messages);

