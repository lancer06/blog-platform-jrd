<?php 
include "check_login.php";
  $notFound = 0;


 ?>
<html>
<head>
    <title>Home</title>
    <link rel="stylesheet"  href="assets/sidebar.css">
    <link rel="stylesheet"  href="assets/main_content.css">
    <link rel="stylesheet"  href="assets/modalstyle.css">
    <link rel="stylesheet" href="assets/fontawesome-free-6.4.0-web/css/all.min.css">
</head>
<body>

<?php
      
      include "includes/get_php/get_post.php";
      include "includes/get_php/get_comment.php";
      include_once "includes/get_php/get_user.php";
      include "assets/sidebar.php";

      $au = $_GET['authorID'];
      


      if(isset($_GET['search'])){
        $key = $_GET['search'];
        $posts = search($db, $key);
        if ($posts == 0) {
            $notFound = 1;
        }
     }else {
        $posts = getByAuthorId($db,$au);
     }
      $categories = get5Categoies($db);

      include "templates/my_blogs_view.php";
?>



</body>
<script src="assets/sidebarscript.js"></script>
<script src="assets/modal.js"></script>
</html>