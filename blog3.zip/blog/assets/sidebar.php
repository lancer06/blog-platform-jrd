<?php
if ($logged) {
    
    $user = getuser($db,$_SESSION['username']);
    $author = getauthor($db, $user['user_id']);
    $au_registered = false;
    
    if($author!=0){
        $au_registered = true;
        $_SESSION['author_id'] =$author['author_id'];
    }
    
}
?>  

<div class="sidebar">
   <div class="logo_content">
        <div class="logo">
            <i class ="fa-solid fa-shield-virus"></i>
            <div class="logo_name">BUG</div>
        </div>
        <i class ="fa-solid fa-list" id="btn"></i>
   </div>

   <ul class="nav_list">
   
        
        <?php if(!$logged){ ?>
        <form action="index.php" method="GET">
        <li>            
                <input type ="text" name="search" placeholder="Search...">
                <button id="search" type="submit">
                <i  class ="fa-solid fa-search"></i>
                </button>          
            <span class="tooltip">Search</span>
        </li>
        </form>
        <li>
            <a class="side_links" href ="index.php">
                <i class ="fa-solid fa-blog"></i>
                <span class="links_name">Blogs</span>
            </a>
            <span class="tooltip">Blogs</span>
        </li>
        <li>
            <a class="side_links" href ="login.php">
                <i class ="fa-solid fa-user"></i>
                <span class="links_name">My Blogs</span>
            </a>
            <span class="tooltip">My Blogs</span>
        </li>
        <li>
            <a class="side_links" href ="category_list.php">
                <i class ="fa-solid fa-clipboard"></i>
                <span class="links_name">Categories</span>
            </a>
            <span class="tooltip">Categories</span>
        </li>
        
        <?php
        } else{ ?>
        <form action="index.php" method="GET">
        <li>            
                <input type ="text" name="search" placeholder="Search...">
                <button id="search" type="submit" name="session" value="<?=$_GET['session']?>">
                <i  class ="fa-solid fa-search"></i>
                </button>          
            <span class="tooltip">Search</span>
        </li>
        </form>
        <li>
            <a class="side_links" href ="index.php?session=<?=$_GET['session']?>">
                <i class ="fa-solid fa-blog"></i>
                <span class="links_name">Blogs</span>
            </a>
            <span class="tooltip">Blogs</span>
        </li>
        <?php
            if($au_registered== true){?>
            <li>
            <a class="side_links" href ="my_blogs.php?authorID=<?=$author['author_id']?>&session=<?=$_GET['session']?>">
                <i class ="fa-solid fa-user"></i>
                <span class="links_name">My Blog Posts</span>
            </a>
            <span class="tooltip">My Blog Posts</span>
            </li>
            <?php
            }else{ ?>
            <li>
            <a class="side_links" href ="templates/register_author.php?user_id=<?=$user['user_id']?>&session=<?=$_GET['session']?>">
                <i class ="fa-solid fa-user"></i>
                <span class="links_name">Author Register</span>
            </a>
            <span class="tooltip">Author Register</span>
            </li>
            <?php
            }
        }    
        ?>
       
        
        <?php if ($logged) { ?>
        <li>
            <a class="side_links" href ="category_list.php?session=<?=$_GET['session']?>">
                <i class ="fa-solid fa-clipboard"></i>
                <span class="links_name">Categories</span>
            </a>
            <span class="tooltip">Categories</span>
        </li>
        
        <li>
            <a class="side_links" href ="templates/messages.php?session=<?=$_GET['session']?>">
                <i class ="fa-solid fa-message"></i>
                <span class="links_name">Messages</span>
            </a>
            <span class="tooltip">Messages</span>
        </li>
        <li>
            <a class="side_links" href ="profile_setting.php?session=<?=$_GET['session']?>">
                <i class ="fa-solid fa-gear"></i>
                <span class="links_name">Profile Settings</span>
            </a>
           <span class="tooltip">Profile Setting</span>
        </li>
        <?php }?>
        
   </ul>
   <div class="profile_content">
        <div class="profile">
            <div class="profile_details">
                <?php if($logged){?>
                    <?php if(empty($user['profilepic'])){?>
                        <img src="assets/img/profile.png" alt="">
                    <?php }else{?>
                        <img src="<?=$user['profilepic']?>" alt="">
                    <?php }?>

                <?php }else{?>
                <img src="assets/img/profile.png" alt="">
                <?php }?>
                <div class="name_job">
                    <?php if ($logged) {                       
                        ?>
                        <div class="name"><?=$_SESSION['username']?></div>
                    <?php } else {?>
                        <div class="name">Log In Account</div>
                    <?php } ?>                                
                </div>
            </div>
            <li>
               <?php if ($logged) {?>
                    <a href="includes/logout.php" id="logout_link">
                    <i class ="fa-solid fa-door-open" id="log_out"></i>
                    </a>          
                    <span class="log_tooltip">Log Out</span>
                <?php } else {?>
                    <a href="login.php" id="logout_link">
                    <i class ="fa-solid fa-arrow-left" id="log_out"></i>
                    </a>          
                    <span class="log_tooltip">Log In</span>
                <?php } ?> 
            </li>
        </div>
   </div>
</div>





