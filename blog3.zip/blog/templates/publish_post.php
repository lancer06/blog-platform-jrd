<?php
    include "../includes/db.php";

    $post_id = $_GET['post_id'];
    $session=$_GET['session'];
    $author_id =$_GET['author_id'];

    $sql = "UPDATE post SET publish=1 WHERE post_id=?";
    $stmt = $db->prepare($sql);
    $stmt->execute([$post_id]);

    header("Location: ../my_blogs.php?authorID=$author_id&session=$session");
    exit;

?>