<?php
    include "../../includes/db.php";
    include "../../includes/get_php/get_post.php";

    $post_id = $_GET['postID'];
    $session =$_GET['session'];
    $user_id = $_GET['userID'];
    if(isset($_POST['comment'])){
        $comment = $_POST['comment'];

        if(empty($comment)){
            header("Location: ../../post_details.php?session=$session&post_ID=$post_id&userID=$user_id&error=Empty Comment");
            exit;
        }else{
                    
            $sql = "INSERT INTO comments(comment, user_id, post_id) VALUES (?,?,?);";
            $stmt = $db->prepare($sql);
            $stmt->execute([$comment,$user_id,$post_id]);

            header("Location: ../../post_details.php?session=$session&post_ID=$post_id&userID=$user_id");
            exit;
        }
    
    }

?>