<div id="pubModal-<?=$post['post_id']?>" class="modal">
                        <!-- Modal content -->
    <div class="modal-content">
    <span class="close" onclick ="CloseModal('pubModal-<?=$post['post_id']?>')">&times;</span>
        <p>Publish Post?</p><br><br>
        <a href="templates/publish_post.php?session=<?=$_GET['session']?>&post_id=<?= $post['post_id']?>&author_id=<?=$au?>" 
            class="choice">Yes</a>
    <button onclick ="CloseModal('pubModal-<?=$post['post_id']?>')"><h3>No</h3></button>
    </div>
</div>