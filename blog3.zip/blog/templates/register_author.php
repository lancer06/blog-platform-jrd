<?php
    include "../includes/db.php";
    include "../includes/get_user.php";

    $Uid = $_GET['user_id'];
    $session=$_GET['session'];
    $user =getuserById($db,$user);

    $sql = "INSERT INTO authors(user_id, username) VALUES (?,?);";
    $stmt = $db->prepare($sql);
    $stmt->execute([$user['user_id'],$user['username']]);

    header("Location: all_blogs.php?session=$session");
    exit;

?>