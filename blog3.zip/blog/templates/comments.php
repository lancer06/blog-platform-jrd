<div class ="post_contain">
            <div>
                <h1 style="color:green;">COMMENTS</h1>
                <br>              
                <?php
                if($comments >0){
                foreach($comments as $comment){ 
                $user =  getuserById($db,$comment['user_id']);         
                    ?>
                     <?php if($logged){
                            $userid=$_GET['userID']?>
                            <?php if($user['user_id']==$userid){?>
                                <?php if(isset($_GET['edit'])){

                                $commID=$_GET['edit'];
                                    if($comment['comment_id']==$commID){?>

                                <form class="post_comment" style="background: #c0ff77;"
                                action="templates/functions/edit_comment.php?postID=<?=$post['post_id']?>&commID=<?=$commID?>
                                &userID=<?=$user['user_id']?>&session=<?=$_GET['session']?>"method="post">
                                    <h3><?=$user['username']?></h3><p><?=$comment['commentdate']?></p>
                                    <br>
                                    <textarea type="text" class="comment-text" name="comment_edit"
                                    id="comment_edit"></textarea>
                                    <br><br>
                                    <button type="submit">Save</button>
                                </form>

                            <script>
                                document.getElementById("comment_edit").value ="<?=$comment['comment']?>";
                            </script>

                            <?php } }else{
                                $text=profanityfilter($comment['comment']);
                                ?>

                                <div class="post_comment" style="background: #c0ff77;">
                                <h3><?=$user['username']?></h3><p><?=$comment['commentdate']?></p>
                                <br><br>
                                <p><?=$text?></p>
                                <br>
                                
                                <a class="del_comm" href="templates/functions/delete-comm.php?postID=<?=$post['post_id']?>&userID=<?=$userid?>
                                &commentID=<?=$comment['comment_id']?>&session=<?=$_GET['session']?>">
                                    <i class ="fa-solid fa-trash"></i></a>
                                <a class="del_comm" 
                                href="post_details.php?session=<?=$_GET['session']?>&post_ID=<?=$post['post_id']?>&userID=<?=$user['user_id']?>&edit=<?=$comment['comment_id']?>">
                                    <i class ="fa-solid fa-pencil"></i></a>
                                <br>
                            </div>
                                <?php }?>
                            <?php }else{
                                $text=profanityfilter($comment['comment']);?>

                            <div class="post_comment">
                                <h4><?=$user['username']?></h3><p><?=$comment['commentdate']?></p>
                                <br><br>
                                <p><?=$text?></p>
                            </div>
                            <?php }?>
                        <?php }else{
                            $text=profanityfilter($comment['comment']);?>
                    <div class="post_comment">
                        <h3><?=$user['username']?></h3><p><?=$comment['commentdate']?></p>
                        <br><br>
                        <p><?=$text?></p>
                    </div>
                    <?php }?>

                       
                    <?php } }else{?>
                        <div class="post_comment">
                        <h3>No Comments yet</p>
                        
                        </div>
                    <?php }?>

                </div>
        <br>
        <div>
<?php
    $postID =$_GET['post_ID'];
	if($logged){
    $userID =$_GET['userID'];
	}
        $sqlCount = "SELECT COUNT(*) AS total FROM comments WHERE post_id=$postID";
        $resultCount = $db->query($sqlCount);
        $rowCount = $resultCount->fetch();
        $totalComments = $rowCount['total'];
        $totalPages = ceil($totalComments / $commentsPerPage);
     
    if($logged){
    for ($i = 1; $i <= $totalPages; $i++) {
        echo "<a href='?post_ID=$postID&userID=$userID&commpage=$i'>$i</a>";
    }}else{
        for ($i = 1; $i <= $totalPages; $i++) {
        echo "<a href='?post_ID=$postID&commpage=$i'>$i</a>";
    }}
?>   
    </div>            

            </div>