<?php if($logged){
    $liked = isLikedByUserID($db, $post['post_id'], $user['user_id']);
    if($liked==1){ ?>

        <i class ="fa-solid fa-thumbs-up liked" id="like_btn-<?=$post['post_id']?>" data-value="<?=$post['post_id']?>" 
        onclick ="loadData('like_btn-<?=$post['post_id']?>','likenum-<?=$post['post_id']?>')" 
        data-value="('<?=$post['post_id']?>')"></i> 
        likes(
        <span id="likenum-<?=$post['post_id']?>"><?php echo  likeCountByPostID($db, $post['post_id']); ?></span> )
<?php }else{?>
        <i class ="fa-solid fa-thumbs-up unliked" id="like_btn-<?=$post['post_id']?>" data-value="<?=$post['post_id']?>" 
        onclick ="loadData('like_btn-<?=$post['post_id']?>','likenum-<?=$post['post_id']?>')" ></i> 
        likes(
        <span id="likenum-<?=$post['post_id']?>"><?php echo  likeCountByPostID($db, $post['post_id']); ?></span> )
<?php }}else{?>
        <?php /*Not logged in */?>
        <i class ="fa-solid fa-thumbs-up" ></i> 
        likes(
        <span><?php echo  likeCountByPostID($db, $post['post_id']); ?></span> )
<?php }?>
