<?php
include "includes/db.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $message = $_POST['message'];

    $stmt = $db->prepare('INSERT INTO messages (message) VALUES (:content)');
    $stmt->execute([':content' => $message]);
}