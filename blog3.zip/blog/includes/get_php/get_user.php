<?php 


// Get All USERS
function getAllUsers($db){
   $sql = "SELECT * FROM user";
   $stmt = $db->prepare($sql);
   $stmt->execute();

   if($stmt->rowCount() >= 1){
   	   $data = $stmt->fetchAll();
   	   return $data;
   }else {
   	 return 0;
   }
}

//get one user
function getuser($db,$username){
   $sql = "SELECT * FROM user WHERE username=?";
   $stmt = $db->prepare($sql);
   $stmt->execute([$username]);

   if($stmt->rowCount() == 1){
   	   $data = $stmt->fetch();
   	   return $data;
   }else {
   	 return 0;
   }
}

function getuserById($db,$user){
   $sql = "SELECT * FROM user WHERE user_id=?";
   $stmt = $db->prepare($sql);
   $stmt->execute([$user]);

   if($stmt->rowCount() == 1){
   	   $data = $stmt->fetch();
   	   return $data;
   }else {
   	 return 0;
   }
}



// Delete By ID
function deleteUserById($db, $id){
   $sql = "DELETE FROM users WHERE id=?";
   $stmt = $db->prepare($sql);
   $res = $stmt->execute([$id]);

   if($res){
   	   return 1;
   }else {
   	 return 0;
   }
}

function getuserId($db,$user){
   $sql = "SELECT user_id FROM user WHERE username=?";
   $stmt = $db->prepare($sql);
   $stmt->execute([$user]);

   if($stmt->rowCount() == 1){
   	   $data = $stmt->fetch();
   	   return $data;
   }else {
   	 return 0;
   }
}

function getAllAuthors($db){
   $sql = "SELECT * FROM user INNER JOIN authors ON user.user_id = authors.user_id";
   $stmt = $db->prepare($sql);
   $stmt->execute();

   if($stmt->rowCount() >= 1){
          $data = $stmt->fetchAll();
          return $data;
   }else {
        return "None";
   }
};

function getauthor($db,$user_id){
   $sql = "SELECT * FROM authors WHERE user_id=?";
   $stmt = $db->prepare($sql);
   $stmt->execute([$user_id]);

   if($stmt->rowCount() == 1){
   	   $data = $stmt->fetch();
   	   return $data;
   }else {
   	 return 0;
   }
}

function getAuthorId($conn,$id){
   $sql = "SELECT author_id FROM authors 
           WHERE user_id=?";
   $stmt = $conn->prepare($sql);
   $stmt->execute([$id]);

   if($stmt->rowCount() >= 1){
   	   $data = $stmt->fetchAll();
   	   return $data;
   }else {
   	 return 0;
   }
}

function getUserAuthorId($db,$id){
   $sql = "SELECT * FROM authors 
           WHERE author_id=?";
   $stmt = $db->prepare($sql);
   $stmt->execute([$id]);

   if($stmt->rowCount() >= 1){
   	   $data = $stmt->fetch();
   	   return $data;
   }else {
   	 return 0;
   }
}

?>