<?php
if(isset($_GET['search'])){
        $key = $_GET['search'];
        $posts = search($db, $key);

        if ($posts == 0) {
            $notFound = 1;
        }
     }else {
        $posts = getAllPost($db);
     }
      $categories = get5Categoies($db); 
?>

<div class="main_content">
    

    <div class="container">
    <aside class="categorybox">
    <div class="category">
     <h2 align ="center">CATEGORY</h2>
        <?php foreach ($categories as $cat) { ?>
            <li><a href="admin_category.php?cat_id=<?=$cat['cat_id']?>"><?=$cat['category_name']?></a></li>
        <?php } ?>
        </div>
    </aside>
   
        <div class="card_container">
        
    <div class="card-table">
        <table style="width:800px;">
            <tr>
                <th>PostID</th>
                <th>Title</th>
                <th>Author</th>
                <th>Category</th>
                <th>Publish Status</th>
                <th>Date</th>
                <th>Actions</th>
         </tr>
        <?php if ($posts != 0) { ?>
        <?php foreach ($posts as $post) { 
            
            $au =getUserAuthorId($db,$post['author_id']);
            

            $category = getCategoryById($db, $post['cat_id']);
            ?> 
            <tr>
                <td><?=$post['post_id']?></td>
                <td class="post_title"><?=$post['title']?></td>
                <td><?=$au['username']?></td>
                <td><?=$category['category_name']?></td>
                <td><?=$post['publish']?></td>
                <td><?=$post['publish_date']?></td>
                <td><a href="">EDIT</a> | <a href="">DELETE</a></td>
            </tr>
        <?php } ?>    
        </table>
    </div>
           
        </div>

        <?php }else { ?>
    </div>


  <?php if($notFound){ ?>
  Not found
  <?php } ?>

<?php } ?>

    


</div>

