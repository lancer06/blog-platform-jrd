<?php 
session_start(); 

include "db.php";
if (isset($_POST['password']) && isset($_POST['username'])) {
    function validate($data){

       $data = trim($data);
       $data = stripslashes($data);
       $data = htmlspecialchars($data);
       return $data;
    }

    

    $password = validate($_POST['password']);
    $username = validate($_POST['username']);

    if(empty($username)){
        header("Location: ../login.php?error=Username is required");
        exit();
    }else if(empty($password)) {
            header("Location: ../login.php?error=Password is required");
            exit();
    }
    else{

        $sql = "SELECT * FROM user WHERE username= :username";
        $result = $db->prepare($sql);
        $result->bindParam(':username', $username);
        $result->execute();
        $result->setFetchMode(PDO::FETCH_ASSOC);

        if ($result->rowCount() === 1) {
            $row = $result->fetch();

            $pass = $row['password'];
            

            if ($row['username']=== $username) {
                if(password_verify($password, $pass)){

                    
                    $user_token = md5(uniqid(rand(1,5), true));

                    $sql = "UPDATE user SET user_session =? WHERE user_id=?";
                    $result = $db->prepare($sql);
                    $result->execute([$user_token, $row['user_id']]);

                    echo "Logged in!";

                    $sql2 = "SELECT * FROM user WHERE user_id=?";
                    $stmt2 = $db->prepare($sql2);
                    $stmt2->execute([$row['user_id']]);
                    $sess= $stmt2->fetch();
                    
                    $user_session= $sess['user_session'];

                    $_SESSION['password'] = $row['password'];
                   
                    
                    
                    header("Location: ../index.php?session=$user_session");
                    exit();
                    }else{
                        header("Location: ../login.php?error=Incorrect password");
                    exit();
                }

            }else{
                header("Location: ../login.php?error=Incorrect username");
                exit();
            }
        }else{
            header("Location: ../login.php?error= Account does not exist");
            exit();
        }
    }

}else{
    header("Location: ../login.php");
    exit();
}